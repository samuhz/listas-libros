
/**
 * Enumeration class Genero - Distintos valores de genero literario
 * 
 * @author (Alberto)
 * @version (1.0)
 */
public enum Genero
{
    NOVELA, POESIA, ENSAYO, TEATRO, CUENTOS, OTRO
}
